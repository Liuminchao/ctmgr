<?php

namespace Mpdf\Tag;

class Nav extends BlockTag
{


}
